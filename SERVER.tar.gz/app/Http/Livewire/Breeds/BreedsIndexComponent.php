<?php

namespace App\Http\Livewire\Breeds;

use Livewire\Component;

class BreedsIndexComponent extends Component
{
    public function render()
    {
        return view('livewire.breeds.breeds-index-component');
    }
}
