<?php

namespace App\Http\Livewire\Hirers;

use App\Models\User;
use Livewire\Component;

class HirersIndexComponent extends Component
{
    public function render()
    {
        return view('livewire.hirers.hirers-index-component');
    }
}
