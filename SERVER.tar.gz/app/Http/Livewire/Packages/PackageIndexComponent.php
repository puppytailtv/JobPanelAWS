<?php

namespace App\Http\Livewire\Packages;

use Livewire\Component;

class PackageIndexComponent extends Component
{
    public function render()
    {
        return view('livewire.packages.packages-index-component');
    }
}
