<?php

namespace App\Http\Livewire\Posts;

use Livewire\Component;

class PostsIndexComponent extends Component
{
    public function render()
    {
        return view('livewire.posts.posts-index-component');
    }
}
