<?php

namespace App\Http\Livewire\States;

use Livewire\Component;

class StatesIndexComponent extends Component
{
    public function render()
    {
        return view('livewire.states.states-index-component');
    }
}
