<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\PostSave;
use Illuminate\Http\Request;

class PostSavesController extends Controller
{
	public function save(Request $request, $post)
	{
		$post = Post::find($post);
		if (!$post)
		{
			return [
				'message' => 'error',
				'error' => 'Post does not exist.'
			];
		}

		$user_saved = false;

		$oldRecord = PostSave::where('post_id', $post->id)->where('user_id', $request->user()->id)->first();

		if (!$oldRecord)
		{
			PostSave::forceCreate([
				'user_id' => $request->user()->id,
				'post_id' => $post->id,
			]);

			$user_saved = true;
		}
		else
		{
			$oldRecord->delete();

			$user_saved = false;
		}

		return [
			'message' => 'success',
			'user_saved' => $user_saved,
			'total_saves' => count($post->saves),
		];
	}
}
