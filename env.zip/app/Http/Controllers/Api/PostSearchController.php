<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Post;
use Illuminate\Http\Request;
use App\Http\Resources\PostResource;

class PostSearchController extends Controller
{
    public function search(Request $request)
    {
        $anyFilter = false;
        $posts = Post::where('is_approved_by_admin',1)
        ->where('active', 1)
        ->with('user')
        ->whereHas('user', function($q) {
            $q->where('active', 1);
            //->where('active_publisher', 1);
        });

        if($request->state_id){
            $anyFilter = true;
            $posts = $posts->where('state_id', $request->state_id);
        }

        if($request->breed_id){
            $anyFilter = true;
            $posts = $posts->where('breed_id', $request->breed_id);
        }

        if($request->sex){
            $anyFilter = true;
            $posts = $posts->where('sex', $request->sex);
        }

        if($request->age){
            $anyFilter = true;
            $posts = $posts->where('age', $request->age);
        }

        if($request->energy_level){
            $anyFilter = true;
            $posts = $posts->where('energy_level', $request->energy_level);
        }

        if($request->size){
            $anyFilter = true;
            $posts = $posts->where('size', $request->size);
        }

        if($request->color_id){
            $anyFilter = true;
            $posts = $posts->where('color_id', $request->color_id);
        }

        if($request->search){
            $anyFilter = true;
            $posts = $posts->where(function($query) use ($request) {
                $query->where('description', 'like',  '%' . $request->search . '%')
                ->orWhere('name', 'like',  '%' . $request->search . '%');
            });
        }

        if (!$anyFilter)
        {
            $posts = $posts->inRandomOrder()->limit(18)->get();
        }
        else
        {        
            $posts = $posts->orderByDesc('created_at')->get();
        }

        return [
            'message' => 'success',
            'data' => PostResource::collection($posts),
        ];
    }
      public function searchMobile(Request $request)
    {
        $posts = Post::where('is_approved_by_admin',1)
        ->where('active', 1)
        ->with('user')
        ->whereHas('user', function($q) {
            $q->where('active', 1);
            //->where('active_publisher', 1);
        });
      
        if($request->state_id != -1){
            $posts = $posts->where('state_id', $request->state_id);
        }

        if($request->breed_id != -1 ){
            $posts = $posts->where('breed_id', $request->breed_id);
        }

        if($request->sex != -1){
            $posts = $posts->where('sex', $request->sex);
        }

        if($request->age != -1){
            $posts = $posts->where('age', $request->age);
        }

        if($request->energy_level != -1){
            $posts = $posts->where('energy_level', $request->energy_level);
        }

        if($request->size != -1 ){
            $posts = $posts->where('size', $request->size);
        }

        if($request->color_id != -1){
            $posts = $posts->where('color_id', $request->color_id);
        }

        if($request->search != -1 ){
            $posts = $posts->where('description', 'like',  '%' . $request->search . '%');
        }
        
        $posts = $posts->get();

        return [
            'message' => 'success',
            'data' => PostResource::collection($posts),
        ];
    }
    public function searchGuest(Request $request)
    {
        $posts = Post::where('is_approved_by_admin',1);

        if($request->state_id){
            $posts = $posts->where('state_id', $request->state_id);
        }

        if($request->sex){
            $posts = $posts->where('sex', $request->sex);
        }

        if($request->age){
            $posts = $posts->where('age', $request->age);
        }

        if($request->energy_level){
            $posts = $posts->where('energy_level', $request->energy_level);
        }

        if($request->size){
            $posts = $posts->where('size', $request->size);
        }

        if($request->breed_id){
            $posts = $posts->where('breed_id', $request->breed_id);
        }

        if($request->color_id){
            $posts = $posts->where('color_id', $request->color_id);
        }

        if($request->search){
            $posts = $posts->where('description', 'like',  '%' . $request->search . '%');
        }
        
        $posts = $posts->get();

        return [
            'message' => 'success',
            'data' => PostResource::collection($posts),
        ];
    }
}
