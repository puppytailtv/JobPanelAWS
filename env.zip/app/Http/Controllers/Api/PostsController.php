<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\{Post,User,DeviceToken};
use Illuminate\Http\Request;
use App\Jobs\SendEmailJob;
use Storage;
use App\Models\Notifications;
use Illuminate\Support\Facades\{DB,Validator,Http,Mail};
use App\Models\Breed;
use App\Models\Color;
use App\Models\State;
use App\Http\Resources\PostResource;

class PostsController extends Controller
{
    public function dropdowns(Request $request)
    {
        return [
            'message' => 'success',
            'breeds' => Breed::where('active', 1)->orderby('name')->get(),
            'colors' => Color::where('active', 1)->orderby('name')->get(),
            'states' => State::where('active', 1)->orderby('name')->get(),
        ];
    }

    public function create(Request $request)
    {
    	$request->validate([
            'name' => 'required|string',
            'breed_id' => 'required|integer|exists:breeds,id',
            'color_id' => 'required|integer|exists:colors,id',
            'sex' => 'required|string|in:Male,Female',
            'age' => 'required|string:in:Unkown,Puppy,Young,Adult,Senior',
            'energy_level' => 'required|string:in:Mellow,Average,Active',
            'size' => 'required|string:in:Small,Medium,Large',
            'state_id' => 'required|integer|exists:states,id',
            'shipping_available' => 'required|string|in:Yes,No',
            //'price' => 'required|integer|min:1',
            'description' => 'required',
            'video' => 'required|mimes:mp4,ogx,oga,ogv,ogg,webm,mov',
            'thumbnail' => 'nullable|image',
        ]);

        $user = $request->user();
        $userPostCount = Post::where('user_id', $user->id)->count();
        $status = 'published';
        if($userPostCount == 0){
            $status = 'under-review';
        }
        $post = Post::forceCreate([
            'name' => $request->name,
            'breed_id' => $request->breed_id,
            'color_id' => $request->color_id,
            'state_id' => $request->state_id,
            'shipping_available' => $request->shipping_available == 'Yes',
            'price' => '0',
            'description' => $request->description,
            'user_id'=> $user->id,
            'video' => $this->storeVideo($request->video),
            'status' => $status,
            'status_description' => $status,
            "sex" =>  $request->sex,
            "age" => $request->age,
            "energy_level" => $request->energy_level,
            "size" => $request->size,
            "active" => 1,
            "is_approved_by_admin" => 1,
            'thumbnail' => $request->has('thumbnail') ? $request->thumbnail->store('/thumbnail') : null,
        ]);
		
          // FireBAse Notification
       // $email = User::where('id',$user->id)->first();
       // $body = $request->user()->name . " Your Post is Pending For Approval By the Admin.";
        //$device_tokens = DeviceToken::where('user_id', $user->id)->pluck('value')->toArray();
       // $additional_info = [
         //   "type" => "Approval",
           // "id"  => $post->id,
       // ];
          
        //if (count($device_tokens) != 0) {
          //  $result =  sendPushNotification($body ,$device_tokens ,$additional_info);
        //}

        # Send Email Notification
        //SendEmailJob::dispatchAfterResponse(new SendEmailJob([
          //  'to' => $email->email,
           // 'title' => 'Alert | Happy tails TV',
           // 'body' => "{$request->user()->name} Your Post is Pending For Approval By the Admin.",
           // 'subject' => 'Alert | Happy tails TV'
       // ]));

       
        # Add Notification to DB
       // Notifications::create([
         //   'title'=>"Happy Tails TV",
          //  'notification'=>"{$request->user()->name} Your Post is Pending For Approval By the Admin.",
           // 'user_id'=>$user->id,
           // 'type'=>'Approval',
            //  'post_id' => $post->id,

        //]);


        return [
            'message' => 'success',
            'data' => new PostResource($post)
        ];
    }
    //update the post 
      public function update(Request $request, $post)
    {
        $post = Post::find($post);
        if (!$post)
        {
            return [
                'message' => 'error',
                'error' => 'Post does not exist.'
            ];
        }

        if ($request->user()->id != $post->user_id)
        {
            return [
                'message' => 'error',
                'error' => "You can not edit other user's post."
            ];
        }

        $request->validate([
            'name' => 'required|string',
            'breed_id' => 'required|integer|exists:breeds,id',
            'color_id' => 'required|integer|exists:colors,id',
            'sex' => 'required|string|in:Male,Female',
            'age' => 'required|string:in:Unkown,Puppy,Young,Adult,Senior',
            'energy_level' => 'required|string:in:Mellow,Average,Active',
            'size' => 'required|string:in:Small,Medium,Large',
            'state_id' => 'required|integer|exists:states,id',
            'shipping_available' => 'required|string|in:Yes,No',
            //'price' => 'required|integer|min:1',
            'description' => 'required',
        ]);

        $user = $request->user();
        $userPostCount = Post::where('user_id', $user->id)->count();
        $status = 'published';
        if($userPostCount == 0){
            $status = 'under-review';
        }

        Post::where('id',$post->id)->update([
            'name' => $request->name,
            'breed_id' => $request->breed_id,
            'color_id' => $request->color_id,
            'state_id' => $request->state_id,
            'shipping_available' => $request->shipping_available == 'Yes',
            'description' => $request->description,
            'status' => $status,
            'status_description' => $status,
            "sex" =>  $request->sex,
            "age" => $request->age,
            "energy_level" => $request->energy_level,
            "size" => $request->size,
            "active" => 1,
            "is_approved_by_admin" => 1,
        ]);
        
        $post = Post::where('id',$post->id)->first();

        return [
            'message' => 'success',
            'data' => new PostResource($post)
        ];
    }
    //end

    public function storeVideo($video)
    {
            $extension = $video->getClientOriginalExtension();
            $name = time().$video->getClientOriginalName();
        // $video->move(public_path('uploads'), $name);
        // return asset('uploads/'.$name);
          //  $filePath = 'postImages/' . $name;
            $filePath = 'PostVideos/' . $name;
            $path = Storage::disk('s3')->put("PostVideos", $video);
           // return $path = Storage::disk('s3')->url($path);
             $filename = explode('.'.$extension, $path);
             $str = $filename[0];
             
             
             $filename = explode('.'."mov", $str);
             $str = $filename[0];
             
            $str2 = substr($str, 11);
           return "https://talhabuckets123123.s3.us-east-2.amazonaws.com/PostVideos/".$str2.".mp4";
           // return "https://d3sv71kjojrkuk.cloudfront.net/PostVideos/HLS/".$str2."_540.m3u8";
            
        //return $video->store('videos');
    }
     public function storethumbnail($thumbnail)
    {
        return $thumbnail->store('/thumbnail');
    }

    public function list(Request $request)
    {
        $posts = Post::where('is_approved_by_admin',1)
            ->where('user_id', $request->user()->id)
            ->where('active', 1)
            ->with('user')
            ->whereHas('user', function($q) {
                $q->where('active', 1);
                //->where('active_publisher', 1);
            })
            ->orderByDesc('created_at')
            ->get();

        return [
            'message' => 'success',
            'data' => PostResource::collection($posts)
        ];
    }


    public function listGuest(Request $request)
    {
        $posts = Post::where('is_approved_by_admin',1)
            ->where('active', 1)
            ->with('user')
            ->whereHas('user', function($q) {
                $q->where('active', 1);
                //->where('active_publisher', 1);
            })
            ->orderByDesc('created_at')
            ->get();

        return [
            'message' => 'success',
            'data' => PostResource::collection($posts)
        ];
    }

    public function getPostById(Request $request)
    {
        $post = Post::find($request->id);
        return [
            'message' => 'success',
            'data' => new PostResource($post)
        ];
    }
     public function deletePostById($id)
    {
        $post = Post::where('id',$id)->update(['active'=> 0 ]);
        return [
            'message' => 'success',
            'data' => new PostResource($post)
        ];
    }

    public function destroy(Request $request, $post)
    {
        $post = Post::find($post);
        if (!$post)
        {
            return [
                'message' => 'error',
                'error' => 'Post does not exist.'
            ];
        }

        if ($request->user()->id != $post->user_id)
        {
            return [
                'message' => 'error',
                'error' => "You can not delete other user's post."
            ];
        }

        if (Post::where('id',$post->id)->update(['active'=> 0 ]))
        {
            return [
                'message' => 'success',
                'data' => new PostResource($post)
            ];
        }
        else
        {
            return [
                'message' => 'error',
                'error' => 'Post not deleted.'
            ];
        }
    }
}
