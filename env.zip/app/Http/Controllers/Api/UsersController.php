<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Jobs\SendEmailJob;
use App\Models\Post;
use App\Models\PostLike;
use App\Models\DeviceToken;
use App\Models\Followings;
use App\Models\Notifications;
use App\Models\User;
use App\Models\Freelancer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\{DB, Validator, Http, Mail};
use Kutia\Larafirebase\Facades\Larafirebase;
// Constants
use App\Constants\ResponseCode;
use App\Constants\Message;
use Twilio\Rest\Client;
use App\Http\Resources\PostResource;
use App\Http\Resources\UserResource;
use App\Http\Resources\FreelancerResource;
use Illuminate\Validation\Rule;

class UsersController extends Controller
{
	public function registerHirer(Request $request)
	{
		$request->validate([
		    'business_name' => 'required|string|max:191',
		    'first_name' => 'required|string|max:191',
		    'last_name' => 'required|string|max:191',
		    'email' => 'required|string|max:191|unique:users,email',
		    'phone' => 'required|string|max:191|unique:users,phone',
		    'password' => 'required|string|confirmed|max:191',
		    'state' => 'required|string|max:191|exists:states,state',
		    'city' => [
		    	'required', 'string', 'max:191',
		    	Rule::exists('states', 'city')->where('state', $request->state),
		    ],
		    'address' => 'required|string',
		    'zip_code' => 'required|string|max:191',
		    'industry' => 'required|string|max:191',
		    'employee_id' => 'nullable|string|max:191',
		]);

		$request->merge([
			'type' => 'hirer',
			'active' => true,
			'password' => \Hash::make($request->password)
		]);

		$user = User::forceCreate(
			$request->only([
				'business_name',
				'first_name',
				'last_name',
				'email',
				'phone',
				'password',
				'state',
				'city',
				'address',
				'zip_code',
				'industry',
				'employee_id',
			])
		);

		$token = $user->createToken('app');

		if (isset($request->FCMToken) && $request->FCMToken) {
			DeviceToken::where('value', $request->FCMToken)->where('user_id', '!=', $user->id)->delete();

			DeviceToken::firstOrCreate(['user_id' => $user->id, 'value' => $request->FCMToken]);
		}

		return [
			'message' => 'success',
			'code' => 200,
			'data' => new UserResource($user),
			'token' => $token->plainTextToken
		];
	}

	public function registerHirerOtp(Request $request)
	{
		$request->validate([
			'otpType' => 'required|string|in:email,phone',
		    'business_name' => 'required|string|max:191',
		    'first_name' => 'required|string|max:191',
		    'last_name' => 'required|string|max:191',
		    'email' => 'required|string|max:191|unique:users,email',
		    'phone' => 'required|string|max:191|unique:users,phone',
		    'password' => 'required|string|confirmed|max:191',
		    'state' => 'required|string|max:191|exists:states,state',
		    'city' => [
		    	'required', 'string', 'max:191',
		    	Rule::exists('states', 'city')->where('state', $request->state),
		    ],
		    'address' => 'required|string',
		    'zip_code' => 'required|string|max:191',
		    'industry' => 'required|string|max:191',
		    'employee_id' => 'nullable|string|max:191',
		]);

		$code = rand(1000, 9999);
		$type = $request->otpType;
		if($type == 'email')
		{
			app('view')->addNamespace('mail', resource_path('views') . '/mail');
			\Mail::send('emails.sendOtp', [
				'email' => $request->email,
				'code' => $code,
			], function ($message) use ($request) {
            // $message->from('info@stackcru.website', 'The Alkhizra Team');
				$message->to($request->email)->subject("Verify Your Email");
			});
		}
		else if ($type == 'phone')
		{
			$message = 'Use the code '.$code .' to verify your Jobreels Account.';

			try 
			{
				$account_sid = getenv("TWILIO_SID");
				$auth_token = getenv("TWILIO_TOKEN");
				$twilio_number = getenv("TWILIO_FROM");

				$client = new Client($account_sid, $auth_token);
				$send = $client->messages->create($request->phone, [
					'from' => $twilio_number, 
					'body' => $message
				]);
			}
			catch (\Exception $e) 
			{
				return [
					'message' => 'error',
					'error' => $e->getMessage()
				];
				//return $response = makeResponse(ResponseCode::FAIL,$e->getMessage(),false);
			}
		}

		$time = time();

		return response([
			'message' => 'success',
			//'verify' => $code,
			'verify' => ($code*$time)+$time,
			'time' => $time,
			'code'   => 200
		], 200);
	}

	public function registerFreelancer(Request $request)
	{
		$request->validate([
		    'first_name' => 'required|string|max:191',
		    'last_name' => 'required|string|max:191',
		    'email' => 'required|string|max:191|unique:users,email',
		    'phone' => 'required|string|max:191|unique:users,phone',
		    'password' => 'required|string|confirmed|max:191',
		    'state' => 'required|string|max:191|exists:states,state',
		    'city' => [
		    	'required', 'string', 'max:191',
		    	Rule::exists('states', 'city')->where('state', $request->state),
		    ],
		    'address' => 'required|string',
		    'portfolio_website' => 'nullable|url|max:191',
			'description' => 'required|string|max:191',
			'salary_requirements' => 'required|string|max:80',
			'full_time' => 'required|string|max:191|in:Full time,Part time',
			'hourly_rate' => 'required|string|max:191',
			'skills_experience' => 'required|string|max:1200',
			'skills_assessment' => 'required|array|min:1',
			'upwork' => 'nullable|string|max:191',
			'fiverr' => 'nullable|string|max:191',
			'linkedin' => 'nullable|string|max:191',
			'youtube' => 'nullable|string|max:191',
			'instagram' => 'nullable|string|max:191',
			'facebook' => 'nullable|string|max:191',
			'tiktok' => 'nullable|string|max:191',
			'twitter' => 'nullable|string|max:191',
			'photo' => 'nullable|image',
			'photo_of_govt_id' => 'nullable|image',
			'photo_with_govt_id' => 'nullable|image',
			'bills' => 'nullable|image',
		]);

		$request->merge([
			'type' => 'freelancer',
			'active' => true,
			'password' => \Hash::make($request->password)
		]);

		$user = User::forceCreate(
			$request->only([
				'first_name',
				'last_name',
				'email',
				'phone',
				'password',
				'state',
				'city',
				'address',
			])
		);

		$request->merge([
			'user_id' => $user->id,
		]);

		$freelancer = Freelancer::forceCreate(
			$request->only([
				'portfolio_website',
				'description',
				'salary_requirements',
				'full_time',
				'hourly_rate',
				'skills_experience',
				'skills_assessment',
				'upwork',
				'fiverr',
				'linkedin',
				'instagram',
				'facebook',
				'youtube',
				'tiktok',
				'twitter',
			])
		);

		$token = $user->createToken('app');

		if (isset($request->FCMToken) && $request->FCMToken) {
			DeviceToken::where('value', $request->FCMToken)->where('user_id', '!=', $user->id)->delete();

			DeviceToken::firstOrCreate(['user_id' => $user->id, 'value' => $request->FCMToken]);
		}

		return [
			'message' => 'success',
			'code' => 200,
			'data' => new UserResource($user),
			'token' => $token->plainTextToken
		];
	}

	public function registerFreelancerOtp(Request $request)
	{
		$request->validate([
		    'first_name' => 'required|string|max:191',
		    'last_name' => 'required|string|max:191',
		    'email' => 'required|string|max:191|unique:users,email',
		    'phone' => 'required|string|max:191|unique:users,phone',
		    'password' => 'required|string|confirmed|max:191',
		    'state' => 'required|string|max:191|exists:states,state',
		    'city' => [
		    	'required', 'string', 'max:191',
		    	Rule::exists('states', 'city')->where('state', $request->state),
		    ],
		    'address' => 'required|string',
		    'portfolio_website' => 'nullable|url|max:191',
			'description' => 'required|string|max:191',
			'salary_requirements' => 'required|string|max:80',
			'full_time' => 'required|string|max:191|in:Full time,Part time',
			'hourly_rate' => 'required|string|max:191',
			'skills_experience' => 'required|string|max:1200',
			'skills_assessment' => 'required|array|min:1',
			'upwork' => 'nullable|string|max:191',
			'fiverr' => 'nullable|string|max:191',
			'linkedin' => 'nullable|string|max:191',
			'youtube' => 'nullable|string|max:191',
			'instagram' => 'nullable|string|max:191',
			'facebook' => 'nullable|string|max:191',
			'tiktok' => 'nullable|string|max:191',
			'twitter' => 'nullable|string|max:191',
			'photo' => 'nullable|image',
			'photo_of_govt_id' => 'nullable|image',
			'photo_with_govt_id' => 'nullable|image',
			'bills' => 'nullable|image',
		]);

		$code = rand(1000, 9999);
		$type = $request->otpType;
		if($type == 'email')
		{
			app('view')->addNamespace('mail', resource_path('views') . '/mail');
			\Mail::send('emails.sendOtp', [
				'email' => $request->email,
				'code' => $code,
			], function ($message) use ($request) {
            // $message->from('info@stackcru.website', 'The Alkhizra Team');
				$message->to($request->email)->subject("Verify Your Email");
			});
		}
		else if ($type == 'phone')
		{
			$message = 'Use the code '.$code .' to verify your Jobreels Account.';

			try 
			{
				$account_sid = getenv("TWILIO_SID");
				$auth_token = getenv("TWILIO_TOKEN");
				$twilio_number = getenv("TWILIO_FROM");

				$client = new Client($account_sid, $auth_token);
				$send = $client->messages->create($request->phone, [
					'from' => $twilio_number, 
					'body' => $message
				]);
			}
			catch (\Exception $e) 
			{
				return [
					'message' => 'error',
					'error' => $e->getMessage()
				];
				//return $response = makeResponse(ResponseCode::FAIL,$e->getMessage(),false);
			}
		}

		$time = time();

		return response([
			'message' => 'success',
			//'verify' => $code,
			'verify' => ($code*$time)+$time,
			'time' => $time,
			'code'   => 200
		], 200);
	}

	public function otp(Request $request)
	{
		$request->validate([
			'email' => 'required|exists:users,email',
			'phone' => 'required|exists:users,phone',
			'type'  => 'required',
		]);

		$code = rand(1000, 9999);
		$type = $request->type;
		$phone = $request->phone;
		if($type == 0 ){
			$email = $request->email;

			app('view')->addNamespace('mail', resource_path('views') . '/mail');
			\Mail::send('emails.sendOtp', [
				'email' => $request->email,
				'code' => $code,
			], function ($message) use ($email) {
            // $message->from('info@stackcru.website', 'The Alkhizra Team');
				$message->to($email)->subject("Verify Your Email");
			});
		}
		else if ($type == 1)
		{
			$receiverNumber = $phone;
			$message = 'Use the code '.$code .' to verify your Happy Tail Account.';

			try {

				$account_sid = getenv("TWILIO_SID");
				$auth_token = getenv("TWILIO_TOKEN");
				$twilio_number = getenv("TWILIO_FROM");

				$client = new Client($account_sid, $auth_token);
				$send =    $client->messages->create($receiverNumber, [
					'from' => $twilio_number, 
					'body' => $message]);
        //return $send;
			}
			catch (\Exception $e) 
			{
				return $response = makeResponse(ResponseCode::FAIL,$e->getMessage(),false);
			}
		}
		return response([
			'message' => 'success',
			'OTPcode' => $code,
			'code'   => 200
		], 200);
	}

	public function login(Request $request)
	{
		$request->validate([
			'email' => 'required',
			'password' => 'required'
		]);

		if (Auth::attempt(['email' => $request->email, 'password' => $request->password]) || Auth::attempt(['username' => $request->email, 'password' => $request->password])) {
			$user = Auth::user();
			$token = $user->createToken('app');

			if (isset($request->FCMToken) && $request->FCMToken) {
				DeviceToken::where('value', $request->FCMToken)->where('user_id', '!=', $user->id)->delete();

				DeviceToken::firstOrCreate(['user_id' => $user->id, 'value' => $request->FCMToken]);
			}

			return [
				'message' => 'success',
				'data' => new UserResource($user),
				'token' => $token->plainTextToken
			];
		} else {
			return response([
				'message' => 'Invalid username or password'
			], 422);
		}
	}

	public function logout(Request $request)
	{
		$user = $request->user();

		if (isset($request->FCMToken) && $request->FCMToken) {
			DeviceToken::where('value', $request->FCMToken)->delete();
		}
	}

	public function forgetOTP(Request $request)
	{
		$request->validate([
			'email' => 'required|exists:users,email',	
		]);
		

		$code = rand(1000, 9999);
		$email = $request->email;
		$user = User::where('email',$email)->first();

		app('view')->addNamespace('mail', resource_path('views') . '/mail');
		\Mail::send('emails.forgetotp', [
			'email' => $request->email,
			'code' => $code,
		], function ($message) use ($email) {
            // $message->from('info@stackcru.website', 'The Alkhizra Team');
			$message->to($email)->subject("OTP");
		});
		return response([
			'message' => 'success',
			'OTPcode' => $code,
			'code'   => 200
		], 200);
	}
	public function forgetPassword(Request $request)
	{
		$request->validate([
			'email' => 'required|exists:users,email',
			'password'          =>  'required|confirmed',
		]);

		$email = $request->email;
		

		$user =  User::where('email', $email)
		->update([
			'password' => bcrypt($request->password),
		]); 
		$user = User::where('email',$email)->first();
		return response([
			'message' => 'success',
			'user' => new UserResource($user),
			'code'   => 200
		], 200);
	}
	public function updateAvatar()
	{
	}

	public function userSavedPosts(Request $request)
	{
		return Post::where('is_approved_by_admin',1)
		->where('active', 1)
		->with(['user', 'saves'])
		->whereHas('user', function($q) {
			$q->where('active', 1);
//			->where('active_publisher', 1);
		})
		->whereHas('saves', function($q) use($request) {
			$q->where('user_id', $request->user()->id);
		})
		->orderByDesc('created_at')
		->get();
	}

	public function savedPosts(Request $request)
	{
		$posts = $this->userSavedPosts($request);

		return [
			'message' => 'success',
			'data' => PostResource::collection($posts)
		];
	}

	public function userLikedPosts(Request $request)
	{
		return Post::where('is_approved_by_admin',1)
		->where('active', 1)
		->with(['user', 'likes'])
		->whereHas('user', function($q) {
			$q->where('active', 1);
			//->where('active_publisher', 1);
		})
		->whereHas('likes', function($q) use($request) {
			$q->where('user_id', $request->user()->id);
		})
		->orderByDesc('created_at')
		->get();
	}

	public function likedPosts(Request $request)
	{
		$posts = $this->userLikedPosts($request);

		return [
			'message' => 'success',
			'data' => PostResource::collection($posts)
		];
	}

	public function profileOLD(Request $request)
	{

		$user = (array)$request->user();

		$data['following'] = Followings::where('follower_id',$request->user()->id)->count(); 
		$data['followers'] = Followings::where('user_id',$request->user()->id)->count(); 
		$post_ids = Post::where('user_id',$request->user()->id)->pluck('id')->toArray();
		$data['likes'] = PostLike::whereIn('post_id',$post_ids)->count();
        //  Post's API
        // User State Name , N# like , N# follower's 
        // Get Profile By ID

        // is_
		return [
			'message' => 'success',
			'data' => $data
		];
	}

	public function update(Request $request)
	{
		$request->validate([
			'name' => 'required|string',
			'phone' => 'required|string',
			'address' => 'required|string',
			'shelter_bio' => 'nullable|string',
			'shelter_city' => 'nullable|string',
			'state_id' => 'nullable|integer',
			'profile_picture' => 'nullable|image'
		]);
		$user = $request->user();
		\Log::info($user);
		\Log::info($request->shelter_bio);

		$arr = [];

		if ($request->has('name'))
			$arr['name'] = $request->name == 'null' ? null : $request->name;
		if ($request->has('username'))
			$arr['username'] = $request->username == 'null' ? null : $request->username;
		if ($request->has('phone'))
			$arr['phone'] = $request->phone == 'null' ? null : $request->phone;
		if ($request->has('address'))
			$arr['address'] = $request->address == 'null' ? null : $request->address;
		if ($request->has('state_id'))
			$arr['state_id'] = $request->state_id == 'null' ? null : $request->state_id;
		if ($request->has('active'))
			$arr['active'] = $request->active == 'null' ? null : $request->active;
		if ($request->has('password'))
			$arr['password'] = $request->password == 'null' ? null : $request->password;
		if ($request->has('shelter_name'))
			$arr['shelter_name'] = $request->shelter_name == 'null' ? null : $request->shelter_name;
		if ($request->has('shelter_city'))
			$arr['shelter_city'] = $request->shelter_city == 'null' ? null : $request->shelter_city;
		if ($request->has('shelter_bio'))
			$arr['shelter_bio'] = $request->shelter_bio == 'null' ? null : $request->shelter_bio;
		if ($request->has('opening_hour'))
			$arr['opening_hour'] = $request->opening_hour == 'null' ? null : $request->opening_hour;
		if ($request->has('closing_hour'))
			$arr['closing_hour'] = $request->closing_hour == 'null' ? null : $request->closing_hour;

		$user->update($arr);

		if ($request->has('profile_picture')) {
			$user->profile_picture = $request->profile_picture->store('/users');
			$user->update();
		}

		\Log::info($request->only([
			'name',
			'username',
			'email',
			'phone',
			'address',
			'state_id',
			'active',
			'password',
			'shelter_name',
			'shelter_city',
			'shelter_bio',
			'opening_hour',
			'closing_hour'
		]));

		return [
			'message' => 'success',
			'data' => new UserResource($user)
		];
	}

	public function getUserById(Request $request)
	{
        //        $user = User::find($request->id);
		$post = Post::with(['color', 'state', 'breed', 'user', 'secondaryBreed'])->where('is_approved_by_admin', 1)->where('active', 1)->where('user_id', $request->id)->get();

		return [
			'message' => 'success',
			'data' => $post
		];
	}

	function follow(Request $request, $user)
	{
		$user = User::find($user);
		if (!$user)
		{
			return [
				'message' => 'error',
				'error' => 'User does not exist.'
			];
		}

		if ($request->user()->id == $user->id) {
			return [
				'message' => 'error',
				'error' => "You can not follow yourself",
			];
		}

		$is_followed = Followings::where('user_id', $user->id)->where('follower_id', $request->user()->id)->exists();
		if ($is_followed) {
			return [
				'message' => 'already',
				'user_followed' => true,
				'total_followers' => count($user->followers),
			];
		}

		$body = $request->user()->name." followed you";
		$device_tokens = DeviceToken::where('user_id', $user->id)->pluck('value')->toArray();
		$additional_info = [
			"type" => "Follow",
			"id"  => $request->user()->id,
		];
		if (count($device_tokens) != 0) {
			sendPushNotification($body, $device_tokens, $additional_info);
		}

        # Add Notification to DB
		Notifications::create([
			'title' => "Happy Tails TV",
			'notification' => "{$request->user()->name} followed you",
			'user_id' => $user->id,
			'type' => 'Follow',
			'post_id' =>  $request->user()->id,
		]);
        # Send Email Notification
        //if ($user) {
            // SendEmailJob
		SendEmailJob::dispatchAfterResponse(new SendEmailJob([
			'to' => $user->email,
			'title' => 'Alert | Happy tails TV',
			'body' => "{$request->user()->name} followed you;",
			'subject' => 'Alert | Happy tails TV'
		]));
        //}

        # Add follow
		$follow = Followings::create([
			'user_id' => $user->id,
			'follower_id' => $request->user()->id
		]);

		return [
			'message' => 'success',
			'user_followed' => true,
			'total_followers' => count($user->followers),
		];
	}

	function unfollow(Request $request, $user)
	{
		$user = User::find($user);
		if (!$user)
		{
			return [
				'message' => 'error',
				'error' => 'User does not exist.'
			];
		}

		$is_followed = Followings::where('user_id', $user->id)->where('follower_id', $request->user()->id)->first();
		if (!$is_followed) {
			return [
				'message' => 'already',
				'user_followed' => false,
				'total_followers' => count($user->followers),
			];
		}

		$is_followed->delete();

		return [
			'message' => 'success',
			'user_followed' => false,
			'total_followers' => count($user->followers),
		];
	}


	function notifications(Request $request)
	{
		$notifications = DB::table('notifications')->select(
			'notifications.id',
			'notifications.type',
			'notifications.title',
			'notifications.notification',
			'notifications.user_id',
			'notifications.post_id',        
			DB::raw('DATE(notifications.created_at) AS date'),
			DB::raw("TIME_FORMAT(notifications.created_at, '%H:%i') AS time")
		)
		->where('user_id',$request->user()->id)
		->orderby('created_at','desc')->get();
		return response()->json(['message' => 'success', 'data' => $notifications]);
	}
	public function listUserFollowing(Request $request)
	{

		$response = getDefaultResponse();
		try 
		{
			$following = Followings::where('follower_id', $request->user()->id)->pluck('user_id');
			$post =  $posts = Post::with(['color', 'state', 'breed', 'user', 'secondaryBreed'])
			->join('users', 'users.id', 'posts.user_id')
			->select(['posts.*',
				\DB::raw("(select count(id) from post_likes where user_id = '" . $request->user()->id . "' and post_id = posts.id) as liked"),
				\DB::raw("(select count(id) from post_saves where user_id = '" . $request->user()->id . "' and post_id = posts.id) as saved"),
				\DB::raw("(select count(id) from followings where follower_id = '" . $request->user()->id . "') as NoOfFollowing"),
				\DB::raw("(select count(id) from followings where user_id = '" . $request->user()->id . "') as NoOfFollowers"),
				\DB::raw("(select count(id) from post_likes where user_id = '" . $request->user()->id . "') as totalLike"),
				\DB::raw("(SELECT IF(COUNT(*) > 0,1,0) FROM followings WHERE followings.user_id=posts.user_id AND followings.follower_id={$request->user()->id}  ) AS is_followed ")
			])
			->where('users.active', 1)
			->where('posts.is_approved_by_admin',1)
			->where('posts.active', 1)
			->orderByDesc('is_featured')
			->whereIn('user_id',$following)
			->withCount('comment as NoOfComments')->get();
			$response = makeResponse(ResponseCode::SUCCESS,Message::REQUEST_SUCCESSFUL,$post,null,true);     
		}
		catch (\Exception $e) 
		{
			$response = makeResponse(ResponseCode::FAIL,$e->getMessage(),false);
		}
		return $response;    
	}
	public function listUserListFollowing(Request $request)
	{

		$response = getDefaultResponse();
		try 
		{
			$following = Followings::where('user_id', $request->user()->id)->pluck('user_id');
			$user = User::whereIn('id',$following)->get();
			$response = makeResponse(ResponseCode::SUCCESS,Message::REQUEST_SUCCESSFUL,$user,null,true);     
		}
		catch (\Exception $e) 
		{
			$response = makeResponse(ResponseCode::FAIL,$e->getMessage(),false);
		}
		return $response;    
	}
	public function contactNumber(Request $request)
	{
		$response = getDefaultResponse();
		$validator = validateData($request,'CHECK_NUMBER');
		if ($validator['status'])
			return makeResponse(ResponseCode::FAIL,$validator['errors']->first(),false,$validator['errors']);  
		$response = getDefaultResponse();
		try 
		{ 
			$phone = $request->phone;
			$result = User::where('phone', $phone)->count();
			$response = makeResponse(ResponseCode::SUCCESS,Message::REQUEST_SUCCESSFUL,$result,null,true);     
		}
		catch (\Exception $e) 
		{
			$response = makeResponse(ResponseCode::FAIL,$e->getMessage(),false);
		}
		return $response;    
	}
	public function list(Request $request)
	{
		$response = getDefaultResponse();
		$validator = validateData($request,'CITIES');
		if ($validator['status'])
			return makeResponse(ResponseCode::FAIL,$validator['errors']->first(),false,$validator['errors']);  
		$response = getDefaultResponse();
		try 
		{ 
			$state = $request->state_id;
			$result = City::where('state_id', $state_id)->get();
			$response = makeResponse(ResponseCode::SUCCESS,Message::REQUEST_SUCCESSFUL,$result,null,true);     
		}
		catch (\Exception $e) 
		{
			$response = makeResponse(ResponseCode::FAIL,$e->getMessage(),false);
		}
		return $response;    
	}


	public function profile(Request $request)
	{
		$response = getDefaultResponse();
		$validator = validateData($request,'PROFILE');
		if ($validator['status'])
			return makeResponse(400,$validator['errors']->first(),false,$validator['errors']);  
		try 
		{ 
			$id = $request->id;
			$result = User::where('id', $id)->with('DeviceToken')->with('state:id,name')->withCount('followingUser as NoOfFollowing')
			->withCount('followerUser as NoOfFollowers')->withCount('postLike as totalLike')->first();
			$response = makeResponse(200,Message::REQUEST_SUCCESSFUL,$result,null,true);     
		}
		catch (\Exception $e) 
		{
			$response = makeResponse(ResponseCode::FAIL,$e->getMessage(),false);
		}
		return $response;    
	}

	public function self(Request $request)
	{
		$posts = Post::where('is_approved_by_admin',1)
		->where('user_id', $request->user()->id)
		->where('active', 1)
		->with('user')
		->whereHas('user', function($q) {
			$q->where('active', 1);
			//->where('active_publisher', 1);
		})
		->orderByDesc('created_at')
		->get();

		$savedPosts = $this->userSavedPosts($request);
		$likedPosts = $this->userLikedPosts($request);

		return [
			'message' => 'success',
			'data' => new UserResource($request->user()),
			'posts' => PostResource::collection($posts),
			'saved_posts' => PostResource::collection($savedPosts),
			'liked_posts' => PostResource::collection($likedPosts),
		];
	}

	public function otherProfile(Request $request, $user)
	{
		$user = User::find($user);
		if (!$user)
		{
			return [
				'message' => 'error',
				'error' => 'User does not exist.'
			];
		}

		$posts = Post::where('is_approved_by_admin',1)
		->where('user_id', $user->id)
		->where('active', 1)
		->with('user')
		->whereHas('user', function($q) {
			$q->where('active', 1);
			//->where('active_publisher', 1);
		})
		->orderByDesc('created_at')
		->get();

		return [
			'message' => 'success',
			'data' => new UserResource($user),
			'posts' => PostResource::collection($posts)
		];
	}

	function send_chat_push(Request $request, $user)
	{
		$user = User::find($user);
		if (!$user)
		{
			return [
				'message' => 'error',
				'error' => 'User does not exist.'
			];
		}

		if ($request->user()->id == $user->id) {
			return [
				'message' => 'error',
				'error' => "You can not send message to yourself",
			];
		}

		$body = $request->message;
		$device_tokens = DeviceToken::where('user_id', $user->id)->pluck('value')->toArray();
		$additional_info = [
			"type" => "Chat",
			"id"  => $request->user()->id,
		];
		if (count($device_tokens) != 0) {
			sendPushNotification($body, $device_tokens, $additional_info, $request->user()->name);
		}
	}
}
