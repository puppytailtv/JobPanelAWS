<?php

namespace App\Http\Livewire\Colors;

use Livewire\Component;

class ColorsIndexComponent extends Component
{
    public function render()
    {
        return view('livewire.colors.colors-index-component');
    }
}
