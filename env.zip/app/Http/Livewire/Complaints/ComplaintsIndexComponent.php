<?php

namespace App\Http\Livewire\Complaints;

use Livewire\Component;

class ComplaintsIndexComponent extends Component
{
    public function render()
    {
        return view('livewire.complaints.complaints-index-component');
    }
}
