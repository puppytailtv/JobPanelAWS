<?php

namespace App\Http\Livewire\Dashboard;

use App\Models\Breed;
use App\Models\Color;
use App\Models\FlagedContent;
use App\Models\Post;
use App\Models\State;
use App\Models\Transaction;
use App\Models\User;
use Livewire\Component;

class DashboardComponent extends Component
{
    public $totalUsers;
    public $totalBreeds;
    public $totalColors;
    public $totalPosts;
    public $totalAdoptions;
    public $totalStates;
    public $totalReports;

    public function mount()
    {
        $this->totalUsers = User::where('type', 'user')->count();
        $this->totalBreeds = Breed::count();
        $this->totalColors = Color::count();
        $this->totalColors = Color::count();
        $this->totalPosts = Post::count();
        $this->totalAdoptions = Transaction::count();
        $this->totalStates = State::count();
        $this->totalReports = FlagedContent::where('resolved', 0)->count();
    }

    public function render()
    {
        return view('livewire.dashboard.dashboard-component');
    }
}
