<?php

namespace App\Http\Livewire\Tables;

use App\Models\Breed;
use App\Models\Color;
use App\Models\Post;
use App\Models\State;
use Mediconesystems\LivewireDatatables\BooleanColumn;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;

class PostsTable extends LivewireDatatable
{
    public function builder()
    {
        return Post::orderby('created_at','desc')->with(['breed', 'color', 'state', 'user']);
    }

    public function columns()
    {
        return [
            Column::callback(['id'], function($id){
                return '<a href='.url('/').'/posts/view?post_id=' . $id . '><i class="badge-circle badge-circle-light-secondary bx bx-edit font-medium-1"></i></a>';
            }),
            Column::name('name')->label("Pup's Name")->searchable(),
            Column::name('breed.name')->label("Breed")->filterable(Breed::pluck('name')),
            Column::name('color.name')->label("Color")->filterable(Color::pluck('name')),
            Column::name('state.name')->label("State")->filterable(State::pluck('name')),
            Column::name('description'),
            Column::name('price'),
            BooleanColumn::name('shipping_available')->label('Shipping'),
            BooleanColumn::name('is_featured')->label('Feature')->filterable(),
            Column::name('status'),
            Column::name('status_description'),
             Column::name('created_at')->label('Post Time'),
            Column::name('user.name')->label('Owner')->searchable(),
        ];
    }
}
