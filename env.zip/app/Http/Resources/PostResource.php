<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\Followings;

class PostResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'self_post' => auth('api')->check() ? auth('api')->id() == $this->user_id : false,
            'user_id' => $this->user_id,
            'breed_id' => $this->breed_id,
            'breed' => $this->breed ? $this->breed->name : null,
            'secondary_breed_id' => $this->secondary_breed_id,
            'secondary_breed' => $this->secondaryBreed ? $this->secondaryBreed->name : null,
            'color_id' => $this->color_id,
            'color' => $this->color ? $this->color->name : null,
            'state_id' => $this->state_id,
            'state' => $this->state ? $this->state->name : null,
            'shipping_available' => $this->shipping_available,
            'price' => $this->price,
            'description' => $this->description,
            'video' => $this->video,
            'status' => $this->status,
            'status_description' => $this->status_description,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'sex' => $this->sex,
            'age' => $this->age,
            'size' => $this->size,
            'energy_level' => $this->energy_level,
            'active' => $this->active,
            'is_featured' => $this->is_featured,
            'is_approved_by_admin' => $this->is_approved_by_admin,
            'thumbnail' => $this->thumbnail,
            'video_url' => $this->video_url,
            'user_liked' => auth('api')->check() ? $this->likes()->where('user_id', auth('api')->id())->exists() : false,
            'user_saved' => auth('api')->check() ? $this->saves()->where('user_id', auth('api')->id())->exists() : false,
            'user_followed' => auth('api')->check() ? Followings::where('follower_id', auth('api')->id())->where('user_id', $this->user_id)->exists() : false,
            'total_likes' => count($this->likes),
            'total_saves' => count($this->saves),
            'total_comments' => count($this->comments),
            'user' => $this->user ? new UserResource($this->user) : null,
        ];
    }
}
