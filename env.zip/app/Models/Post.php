<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;

    protected $appends = [
        'video_url', 'likes', 'saves'
    ];

    public function getVideoUrlAttribute()
    {
        //return url('/uploads/' . $this->video);

        return $this->video;
    }

    public function getTotalLikesAttribute()
    {
        return PostLike::where('post_id', $this->id)->count();
    }

    public function getTotalSavesAttribute()
    {
        return PostSave::where('post_id', $this->id)->count();
    }

    public function breed()
    {
        return $this->belongsTo(Breed::class)->orderby('name');
    }

    public function secondaryBreed()
    {
        return $this->belongsTo(Breed::class, 'secondary_breed_id', 'id')->orderby('name');
    }

    public function color()
    {
        return $this->belongsTo(Color::class)->orderby('name');
    }

    public function state()
    {
        return $this->belongsTo(State::class)->orderby('name');
    }

    public function likes()
    {
        return $this->hasMany(PostLike::class);
    }

    public function saves()
    {
        return $this->hasMany(PostSave::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function UserData()
    {
        return $this->belongsTo(User::class);
    }
    public function comments()
    {
        return $this->hasMany(Comment::class);
    }
    
    public function followingUser()
    {
        return $this->hasManyThrough(Followings::class, User::class, 'id', 'follower_id', 'user_id', 'id');
    }
}
