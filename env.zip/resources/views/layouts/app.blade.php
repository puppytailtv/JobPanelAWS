<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="Puppytail TV admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, Puppytail TV admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>Puppy Tail TV</title>
    <link rel="apple-touch-icon" href="{{url('/')}}/app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="{{url('/')}}/app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="{{url('/app-assets/vendors/css/vendors.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/vendors/css/extensions/dragula.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/css/colors.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/css/components.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/css/themes/semi-dark-layout.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/css/pages/widgets.css">
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/css/pages/dashboard-analytics.css">
    <!-- END: Page CSS-->
    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/assets/css/style.css">
    <!-- END: Custom CSS-->
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css"
          rel="stylesheet"
    >
    <link rel="stylesheet" type="text/css" href="{{url('/')}}/app-assets/css/pages/dashboard-ecommerce.css">
    
    <link rel="stylesheet" type="text/css" href="https://cdn.tutorialjinni.com/toastr.js/2.1.4/toastr.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.tutorialjinni.com/toastr.js/2.1.4/toastr.css">
    
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.8.2/dist/alpine.min.js" defer></script>
    <script src="https://cdn.tutorialjinni.com/toastr.js/2.1.4/toastr.min.js"></script>

    <style>
    .badge-circle
    {
    display: inline-flex !important;
        margin-left: 5px;
    }
    </style>
    @livewireStyles

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern boxicon-layout no-card-shadow 2-columns navbar-sticky footer-static " data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">

    <!-- BEGIN: Header-->
    <div class="header-navbar-shadow"></div>
    <nav class="header-navbar main-header-navbar navbar-expand-lg navbar navbar-with-menu fixed-top ">
        <div class="navbar-wrapper">
            <div class="navbar-container content">
                <div class="navbar-collapse" id="navbar-mobile">
                    <div class="float-left mr-auto bookmark-wrapper d-flex align-items-center">
                    </div>
                    <ul class="float-right nav navbar-nav">

                        <livewire:user-nav-menu />
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <!-- END: Header-->


    <!-- BEGIN: Main Menu-->
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
        <div class="navbar-header">
            <ul class="flex-row nav navbar-nav">
                <li class="mr-auto nav-item"><a class="navbar-brand" href="{{url('/')}}/dashboard">
                        <div class="brand-logo">
                            <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 1000 1000" style="enable-background:new 0 0 1000 1000;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#0BABD4;}
</style>
<g>
	<g>
		<g>
			<path class="st0" d="M546.8,397.6l47.2,35.5c8.5,6.4,8.5,19.1,0,25.5l-47.2,35.5c-10.5,7.9-25.6,0.4-25.6-12.8v-71
				C521.3,397.2,536.3,389.7,546.8,397.6z"/>
			<g>
				<path class="st0" d="M349.6,353.8l71.7,9.4c26.5-16.2,57.1-24.7,88.7-24.7c30.2,0,59.3,7.7,84.8,22.3l29.5-29.3
					c5.8-5.8,14.4-14.3,25.7-19.4c-38.1-36.4-89.7-58.8-146.6-58.8c-75.8,0-142.3,39.8-179.8,99.6c2.7-0.3,5.4-0.5,8.3-0.5
					C338.7,352.4,344.7,353.2,349.6,353.8z"/>
				<path class="st0" d="M673.5,492.3c0,84.8-73.3,153.8-163.4,153.8c-75.5,0-141.2-49.5-158.8-117.4c-3.3,1.3-6.5,2.4-9.7,3.4
					c-7.9,2.5-16.6-0.1-21.9-6.3c-11.4-13.5-20.7-28.6-27.6-44.7c8.1,109.8,99.6,196.3,211.5,196.3c117.1,0,212.1-95,212.1-212.1
					c0-1.2-0.1-2.4-0.1-3.7c-8.7-8-29.6-24.8-54.9-29.2C669.1,451.3,673.5,471.6,673.5,492.3z"/>
			</g>
			<path d="M464.8,451.7c6.4,0,11.6-5.2,11.6-11.6s-5.2-11.6-11.6-11.6s-11.6,5.2-11.6,11.6S458.4,451.7,464.8,451.7z M549.3,451.7
				c6.4,0,11.6-5.2,11.6-11.6s-5.2-11.6-11.6-11.6s-11.6,5.2-11.6,11.6S542.9,451.7,549.3,451.7z M711.4,345.9
				c-12.3-17.6-26.5-26.9-41.2-26.9c-0.8,0-1.6,0-2.5,0.1c-3.1,0.2-6.1,0.9-8.9,1.8c-11.3,3.8-20.1,12.5-26.3,18.7l-35.9,35.7
				c-25.5-16.6-55.2-25.4-86.5-25.4c-32,0-61.6,9.3-86.1,25.2l-75.8-10c-8.7-1.1-20.9-2.7-32.1,1c-2.9,1-5.7,2.3-8.4,4
				c-13,8.6-19.4,25.1-18.4,47.8c0.4,8.8,1.5,17.6,3.3,26.3c5.6,27.2,18,52.8,36,74.1c1.7,2.1,4.3,3.2,6.9,3.2
				c0.9,0,1.8-0.1,2.7-0.4c7.4-2.4,14.6-5.3,21.6-8.7c10.5,68.9,73.9,122.1,150.4,122.1c83.8,0,151.9-63.8,151.9-142.3
				c0-25.6-7.2-50.3-20.9-72c2.4-0.2,4.9-0.4,7.4-0.4c27.8,0,52,14.9,66.3,26c5,3.9,8.8,7.4,11.1,9.6c2.5,2.5,6.3,3.2,9.6,1.9
				c3.3-1.3,5.5-4.4,5.7-7.9C743,412.8,732.4,376,711.4,345.9z M711.1,421.5c-16.3-10.1-38.1-19.6-62.6-19.6c-6,0-12,0.6-17.8,1.7
				c-2.4,0.5-4.9,1-7.4,1.8c-2.9,0.8-5.2,3-6.1,5.9c-0.9,2.9-0.4,6,1.5,8.4c16.6,21.3,25.4,46.5,25.4,72.8
				c0,68.5-60.1,124.3-133.9,124.3c-69.9,0-127.5-50-133.4-113.5c9.4-5.9,18.2-12.6,26.2-20.2c18.2-17.3,32.7-38.8,41.7-62.2
				c1.8-4.6-0.5-9.9-5.2-11.7c-2-0.8-4.1-0.7-6-0.1c-2.5,0.8-4.7,2.7-5.7,5.3c-8.1,21-21,40.2-37.3,55.6c-4.3,4.1-9,7.9-13.8,11.5
				c-3.1,2.3-6.2,4.4-9.4,6.5c-3,1.9-6,3.7-9.1,5.3c-6.4,3.4-13,6.4-19.8,8.9c-18.8-24.2-29.8-54.1-31.2-84.7
				c-0.4-9.1,0.4-25.4,10.3-31.9c7-4.6,17.4-3.7,28.3-2.2l58.1,7.6l11.9,1.6l8.8,1.2c1.4,0.2,2.7,0,3.9-0.4l0.2,0.7
				c22.6-16.1,50.8-25.7,81.5-25.7c30.1,0,58.6,9.1,82.3,26.3c3.6,2.6,8.5,2.2,11.6-0.9l41.2-41c7.8-7.8,15.5-14.8,23.8-15.4
				c0.4,0,0.8,0,1.2,0c0.8,0,1.5,0.1,2.3,0.2c10.4,1.5,19.4,12.3,24.1,19c15.1,21.6,24.1,47.1,26.2,73.2
				C719.3,426.8,715.4,424.1,711.1,421.5z M532.7,517.3c-31.9,0-57.7,16-57.7,35.7c0,19.7,25.7,35.6,57.4,35.7
				c-9.5,7.2-20.9,11.8-32.7,12.9c-21.3,1.9-43.3-8-56.1-25.2c-12.3-16.6-15.7-39.5-8.8-58.9c5.1,1.9,9.3,6.5,10.2,11.9
				c0.3,1.9,2,3.2,3.8,3.2c0.2,0,0.4,0,0.7-0.1c2.1-0.4,3.5-2.4,3.1-4.5c-1.6-9.4-9.7-17.3-19.1-18.9c-9.4-1.5-19.6,3.4-24.1,11.8
				c-1,1.9-0.3,4.2,1.5,5.2c1.9,1,4.2,0.3,5.2-1.5c2.2-4,6.2-6.8,10.6-7.7c-6.8,21.4-2.8,46,10.6,64c13.2,17.7,35.1,28.5,57.2,28.5
				c1.9,0,3.9-0.1,5.8-0.3c16.8-1.5,32.8-9.4,44.6-21.4c26-3.5,45.4-17.8,45.4-34.9C590.4,533.3,564.5,517.3,532.7,517.3z"/>
		</g>
	</g>
	<g>
		<path d="M392.2,698.4v11.3h10.9v-11.3h6.6v29.3h-6.6v-12.3h-10.9v12.3h-6.7v-29.3H392.2z"/>
		<path d="M433.1,722.5c0,2,0.1,4,0.3,5.2h-6l-0.4-2.1h-0.1c-1.4,1.7-3.6,2.6-6.1,2.6c-4.3,0-6.9-3.1-6.9-6.5c0-5.5,5-8.2,12.5-8.1
			v-0.3c0-1.1-0.6-2.7-3.9-2.7c-2.2,0-4.5,0.7-5.9,1.6l-1.2-4.3c1.5-0.8,4.4-1.9,8.3-1.9c7.1,0,9.4,4.2,9.4,9.2V722.5z M426.6,717.6
			c-3.5,0-6.2,0.8-6.2,3.3c0,1.7,1.1,2.5,2.6,2.5c1.7,0,3-1.1,3.4-2.4c0.1-0.3,0.1-0.7,0.1-1.1V717.6z"/>
		<path d="M438.3,713.5c0-2.8-0.1-5.2-0.2-7.1h5.7l0.3,3h0.1c1.6-2.3,4-3.4,7.1-3.4c4.7,0,8.8,4,8.8,10.8c0,7.7-4.9,11.4-9.7,11.4
			c-2.6,0-4.6-1-5.5-2.4h-0.1v10.6h-6.6V713.5z M444.9,718.5c0,0.5,0,1,0.1,1.4c0.4,1.8,2,3.1,3.9,3.1c2.9,0,4.6-2.4,4.6-6
			c0-3.4-1.5-6-4.5-6c-1.9,0-3.5,1.4-4,3.3c-0.1,0.3-0.1,0.8-0.1,1.2V718.5z"/>
		<path d="M464.3,713.5c0-2.8-0.1-5.2-0.2-7.1h5.7l0.3,3h0.1c1.6-2.3,4-3.4,7.1-3.4c4.7,0,8.8,4,8.8,10.8c0,7.7-4.9,11.4-9.7,11.4
			c-2.6,0-4.6-1-5.5-2.4h-0.1v10.6h-6.6V713.5z M470.9,718.5c0,0.5,0,1,0.1,1.4c0.4,1.8,2,3.1,3.9,3.1c2.9,0,4.6-2.4,4.6-6
			c0-3.4-1.5-6-4.5-6c-1.9,0-3.5,1.4-4,3.3c-0.1,0.3-0.1,0.8-0.1,1.2V718.5z"/>
		<path d="M494.9,706.4l3.2,10.4c0.3,1.3,0.8,2.8,1,4h0.1c0.3-1.1,0.7-2.7,1-4l2.6-10.4h7.1l-5,14c-3,8.4-5.1,11.8-7.5,14
			c-2.3,2-4.7,2.7-6.4,2.9l-1.4-5.6c0.8-0.1,1.9-0.5,2.9-1.1c1-0.5,2.1-1.6,2.7-2.7c0.2-0.3,0.3-0.7,0.3-1c0-0.2,0-0.6-0.3-1.1
			l-7.8-19.4H494.9z"/>
		<path d="M516.9,703.9h-7.9v-5.6h22.5v5.6h-8v23.8h-6.7V703.9z"/>
		<path d="M549.8,722.5c0,2,0.1,4,0.3,5.2h-6l-0.4-2.1h-0.1c-1.4,1.7-3.6,2.6-6.1,2.6c-4.3,0-6.9-3.1-6.9-6.5c0-5.5,5-8.2,12.5-8.1
			v-0.3c0-1.1-0.6-2.7-3.9-2.7c-2.2,0-4.5,0.7-5.9,1.6l-1.2-4.3c1.5-0.8,4.4-1.9,8.3-1.9c7.1,0,9.4,4.2,9.4,9.2V722.5z M543.3,717.6
			c-3.5,0-6.2,0.8-6.2,3.3c0,1.7,1.1,2.5,2.6,2.5c1.7,0,3-1.1,3.4-2.4c0.1-0.3,0.1-0.7,0.1-1.1V717.6z"/>
		<path d="M561.8,700.5c0,1.8-1.4,3.3-3.6,3.3c-2.1,0-3.5-1.5-3.4-3.3c0-1.9,1.3-3.3,3.5-3.3C560.4,697.1,561.8,698.6,561.8,700.5z
			 M555,727.7v-21.3h6.6v21.3H555z"/>
		<path d="M566.9,696.8h6.6v30.9h-6.6V696.8z"/>
		<path d="M578.8,721.9c1.2,0.7,3.7,1.6,5.7,1.6c2,0,2.8-0.7,2.8-1.8c0-1.1-0.7-1.6-3.1-2.4c-4.4-1.5-6.1-3.9-6-6.4c0-4,3.4-7,8.7-7
			c2.5,0,4.7,0.6,6,1.2l-1.2,4.6c-1-0.5-2.8-1.2-4.6-1.2c-1.6,0-2.5,0.7-2.5,1.7c0,1,0.8,1.5,3.4,2.4c4,1.4,5.7,3.4,5.8,6.6
			c0,4-3.1,6.9-9.2,6.9c-2.8,0-5.3-0.7-6.9-1.5L578.8,721.9z"/>
		<path d="M600.7,728.2c-2.2,0-3.8-1.7-3.8-4c0-2.3,1.6-4,3.9-4s3.9,1.7,3.9,4C604.6,726.5,603.1,728.2,600.7,728.2L600.7,728.2z"/>
		<path class="st0" d="M616,700.6v5.8h4.7v4.9H616v7.7c0,2.6,0.6,3.7,2.6,3.7c0.9,0,1.3,0,2-0.2l0,5c-0.9,0.3-2.4,0.6-4.3,0.6
			c-2.1,0-3.9-0.8-5-1.9c-1.2-1.3-1.8-3.3-1.8-6.3v-8.7h-2.8v-4.9h2.8v-4L616,700.6z"/>
		<path class="st0" d="M629.7,706.4l2.9,9.9c0.5,1.8,0.9,3.5,1.2,5.2h0.1c0.3-1.7,0.7-3.3,1.2-5.2l2.7-9.9h7l-7.9,21.3h-6.6
			l-7.7-21.3H629.7z"/>
	</g>
</g>
</svg>

                        </div>
                        <h2 class="mb-0 brand-text">Welcome</h2>
                    </a></li>
                <li class="nav-item nav-toggle"><a class="pr-0 nav-link modern-nav-toggle" data-toggle="collapse"><i class="bx bx-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i class="toggle-icon bx bx-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary" data-ticon="bx-disc"></i></a></li>
            </ul>
        </div>
        <div class="shadow-bottom"></div>
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="">
                <li class="nav-item has-sub sidebar-group-active open"><a href=""><i class="bx bx-home-alt"></i><span class="menu-title text-truncate" data-i18n="Dashboard">Users</span></a>
                    <ul class="menu-content">
                        <li class=""><a class="d-flex align-items-center" href="{{url('/')}}/users/list"><i class="bx bx-right-arrow-alt"></i><span class="menu-item text-truncate" data-i18n="eCommerce">List</span></a>
                        </li>
                        <li class=""><a class="d-flex align-items-center" href="{{url('/')}}/users/pending-approval"><i class="bx bx-right-arrow-alt"></i><span class="menu-item text-truncate" data-i18n="eCommerce">Pending Approval</span></a>
                        </li>
                    </ul>
                </li>
            </ul>
            <ul class="mt-1 navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="">
                <li class="nav-item has-sub sidebar-group-active open"><a href=""><i class="bx bx-home-alt"></i><span class="menu-title text-truncate" data-i18n="Dashboard">Posts</span></a>
                    <ul class="menu-content">
                        <li class=""><a class="d-flex align-items-center" href="{{url('/')}}/posts/list"><i class="bx bx-right-arrow-alt"></i><span class="menu-item text-truncate" data-i18n="eCommerce">List</span></a>
                        </li>
                    </ul>
                </li>
            </ul>
            <ul class="mt-1 navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="">
                <li class="nav-item has-sub sidebar-group-active open"><a href=""><i class="bx bx-home-alt"></i><span class="menu-title text-truncate" data-i18n="Dashboard">Adoption</span></a>
                    <ul class="menu-content">
                        <li class=""><a class="d-flex align-items-center" href="{{url('/')}}/adoptions/list"><i class="bx bx-right-arrow-alt"></i><span class="menu-item text-truncate" data-i18n="eCommerce">Adoption Requests</span></a>
                        </li>
                    </ul>
                </li>
            </ul>
            <ul class="mt-1 navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="">
                <li class="nav-item has-sub sidebar-group-active open"><a href=""><i class="bx bx-home-alt"></i><span class="menu-title text-truncate" data-i18n="Dashboard">Complaints</span></a>
                    <ul class="menu-content">
                        <li class=""><a class="d-flex align-items-center" href="{{url('/')}}/complaints/list"><i class="bx bx-right-arrow-alt"></i><span class="menu-item text-truncate" data-i18n="eCommerce">List</span></a>
                        </li>
                    </ul>
                </li>
            </ul>
            <ul class="mt-1 navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="">
                <li class="nav-item has-sub sidebar-group-active open"><a href=""><i class="bx bx-home-alt"></i><span class="menu-title text-truncate" data-i18n="Dashboard">Reports</span></a>
                    <ul class="menu-content">
                        <li class=""><a class="d-flex align-items-center" href="{{url('/')}}/posts/flagged"><i class="bx bx-right-arrow-alt"></i><span class="menu-item text-truncate" data-i18n="eCommerce">List</span></a>
                        </li>
                    </ul>
                </li>
            </ul>
            <ul class="mt-1 navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="">
                <li class="nav-item has-sub sidebar-group-active open"><a href=""><i class="bx bx-home-alt"></i><span class="menu-title text-truncate" data-i18n="Dashboard">Settings</span></a>
                    <ul class="menu-content">
                        <li class=""><a class="d-flex align-items-center" href="{{url('/')}}/breeds/list"><i class="bx bx-right-arrow-alt"></i><span class="menu-item text-truncate" data-i18n="eCommerce">Breeds</span></a>
                        </li>
                        <li class=""><a class="d-flex align-items-center" href="{{url('/')}}/colors/list"><i class="bx bx-right-arrow-alt"></i><span class="menu-item text-truncate" data-i18n="eCommerce">Colors</span></a>
                        </li>
                        <li class=""><a class="d-flex align-items-center" href="{{url('/')}}/states/list"><i class="bx bx-right-arrow-alt"></i><span class="menu-item text-truncate" data-i18n="eCommerce">States</span></a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
    <!-- END: Main Menu-->

    <!-- BEGIN: Content-->
    {{$slot}}
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light">
        {{-- <p class="clearfix mb-0"><span class="float-left d-inline-block">2021 &copy; PIXINVENT</span><span class="float-right d-sm-inline-block d-none">Crafted with<i class="bx bxs-heart pink mx-50 font-small-3"></i>by<a class="text-uppercase" href="https://1.envato.market/pixinvent_portfolio" target="_blank">Pixinvent</a></span>
            <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="bx bx-up-arrow-alt"></i></button>
        </p> --}}
    </footer>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="{{url('/')}}/app-assets/vendors/js/vendors.min.js"></script>
    <script src="{{url('/')}}/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.js"></script>
    <script src="{{url('/')}}/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js"></script>
    <script src="{{url('/')}}/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="{{url('/')}}/app-assets/vendors/js/extensions/dragula.min.js"></script>
    <script src="{{url('/')}}/app-assets/vendors/js/extensions/swiper.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="{{url('/')}}/app-assets/js/core/app-menu.js"></script>
    <script src="{{url('/')}}/app-assets/js/core/app.js"></script>
    <script src="{{url('/')}}/app-assets/js/scripts/components.js"></script>
    <script src="{{url('/')}}/app-assets/js/scripts/footer.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="{{url('/')}}/app-assets/js/scripts/pages/dashboard-analytics.js"></script>
    <!-- END: Page JS-->
    <script>
    
<script type="text/javascript">

	var Toast = Swal.mixin({
		toast: true,
		position: 'top',
		showConfirmButton: false,
		timer: 3000
	});

	function toast_error(message){
		toastr.error(message)
	}

	function toast_success(message){
		toastr.success(message)
	}

	function toast_info(message){
		toastr.info(message)
	}

    </script>
    @livewireScripts
</body>
<!-- END: Body-->

</html>
