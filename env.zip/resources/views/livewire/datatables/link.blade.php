<a href="{{ $href }}" class="px-3 py-1 text-blue-600 border-2 border-transparent rounded-lg hover:border-blue-500 hover:bg-blue-100 hover:shadow-lg">{{ $slot }}</a>
