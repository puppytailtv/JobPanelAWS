<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="mt-1 mb-2 content-header-left col-12">
                <div class="breadcrumbs-top">
                    <h5 class="float-left pr-1 mb-0 content-header-title">Posts</h5>
                    <div class="breadcrumb-wrapper d-none d-sm-block">
                        <ol class="p-0 pl-1 mb-0 breadcrumb">
                            <li class="breadcrumb-item"><a href="{{url('/')}}"><i class="bx bx-home-alt"></i></a>
                            </li>
                            <li class="breadcrumb-item active">View
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <div class="row">
                <div class="col-7">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">{{$post->name}}</h4>
                        </div>
                        <div class="card-body">
                            <video controls="true">
                                <source src="{{url('/')}}/uploads/{{$post->video}}" />
                            </video>
                            <p class="mt-1 mb-1">
                                <b>Color:</b> {{$post->color->name}} <b>Breed:</b> {{$post->breed->name}} <b>State:</b> {{$post->state->name}}
                            </p>

                            <b class="mt-1 mb-1">Description</b>
                            <p class="mt-1 mb-1">
                                {{$post->description}}
                            </p>
                            <div class="avatar mr-1 avatar-xl">
                                <img src="{{url('/')}}/uploads/{{$post->user->profile_picture}}" alt="avtar img holder">
                            </div>
                            <a href="{{url('/')}}/users/detail?user_id={{$post->user->id}}">{{$post->user->name}}</a>
                        </div>
                    </div>
                </div>
                <div class="col-5">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Comments</h4>
                        </div>
                        <div class="card-body">
                            <div class="row" style="height: 400px; overflow:scroll;">
                                @foreach($comments as $key => $comment)
                                <div class="col-12 border-bottom">
                                    <div class="avatar mr-1 avatar-xl">
                                        <a href="{{url('/')}}/users/detail?user_id={{$comment->user->id}}"><img src="{{url('/')}}/uploads/{{$comment->user->profile_picture}}" alt="avtar img holder"></a>
                                    </div>
                                        {{$comment->comment}}
                                    <h2><a href="{{url('/')}}/users/detail?user_id={{$comment->user->id}}">{{$comment->user->name}}</a></h2>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-7">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Reports</h4>
                        </div>
                        <div class="card-body">
                            <div class="row" style="height: 400px; overflow:scroll;">
                                @foreach($reports as $key => $report)
                                <div class="col-12 border-bottom">
                                    <div class="avatar mr-1 avatar-xl">
                                        <a href="{{url('/')}}/users/detail?user_id={{$report->user->id}}"><img src="{{url('/')}}/uploads/{{$report->user->profile_picture}}" alt="avtar img holder"></a>
                                    </div>
                                    <div style="display: inline-block">
                                        <div class="chip chip-danger mr-1">
                                            <div class="chip-body">
                                                <span class="chip-text">{{$report->flag->name}}</span>
                                                <div class="chip-closeable">
                                                    <i class="bx bx-x"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                            <b>Description:</b>
                                            {{$report->description}}

                                    </div>
                                    <h2><a href="{{url('/')}}/users/detail?user_id={{$report->user->id}}">{{$report->user->name}}</a></h2>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-5">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Action</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <label for="">Action Taken</label>
                                    <select wire:model="actionTaken" name="" id="" class="form-control">
                                        <option value="">Select Action
                                        </option>
                                        @foreach($actions as $action)
                                        <option value="{{$action}}">{{$action}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-12 mt-1">
                                    <div class="custom-control custom-switch custom-control-inline mb-1">
                                        <input wire:model="userStatus" type="checkbox" class="custom-control-input" checked id="customSwitch1">
                                        <label class="custom-control-label mr-1" for="customSwitch1">
                                        </label>
                                        <span>Account Active</span>
                                    </div>
                                </div>
                                <div class="col-12 mt-1">
                                    <div class="custom-control custom-switch custom-control-inline mb-1">
                                        <input wire:model="postStatus" type="checkbox" class="custom-control-input" checked id="customSwitch2">
                                        <label class="custom-control-label mr-1" for="customSwitch2">
                                        </label>
                                        <span>Post Active</span>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <label for="">Action Description</label>
                                    <textarea class="form-control" wire:model="actionDescription"></textarea>
                                </div>
                                <div class="col-12 mt-1">
                                    <button wire:click="save" class="btn btn-md btn-primary">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
