<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="mt-1 mb-2 content-header-left col-12">
                <div class="breadcrumbs-top">
                    <h5 class="float-left pr-1 mb-0 content-header-title">Posts</h5>
                    <div class="breadcrumb-wrapper d-none d-sm-block">
                        <ol class="p-0 pl-1 mb-0 breadcrumb">
                            <li class="breadcrumb-item"><a href="/"><i class="bx bx-home-alt"></i></a>
                            </li>
                            <li class="breadcrumb-item active">View
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <div class="row">
                <div class="col-7">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">{{$post->name}}</h4>
                        </div>
                        <div class="card-body">
                            <video controls="true">
                                <source src="{{url('/')}}/uploads/{{$post->video}}" />
                            </video>
                            <div class="mt-1 col-12">
                                <div class="mb-1 custom-control custom-switch custom-control-inline">
                                    <input wire:model="post.active" wire:change='update' type="checkbox" class="custom-control-input" checked id="customSwitch2">
                                    <label class="mr-1 custom-control-label" for="customSwitch2">
                                    </label>
                                    <span>Post Active</span>
                                </div>
                                 <div class="mb-1 custom-control custom-switch custom-control-inline">
                                    <input wire:model="post.is_approved_by_admin" wire:change='postapproved' type="checkbox" class="custom-control-input" checked id="customSwitch3">
                                    <label class="mr-1 custom-control-label" for="customSwitch3">
                                    </label>
                                    <span>Post Approved</span>
                                </div>
                                <div class="mb-1 custom-control custom-switch custom-control-inline">
                                    <input wire:model="post.is_featured" wire:change='update' type="checkbox" class="custom-control-input" checked id="customSwitch1">
                                    <label class="mr-1 custom-control-label" for="customSwitch1">
                                    </label>
                                    <span>Post Featured</span>
                                </div>
                            </div>
                            <p class="mt-1 mb-1">
                                <b>Color:</b> {{$post->color->name ?? ''}} <b>Breed:</b> {{$post->breed->name ?? '' }} <b>State:</b> {{$post->state->name ?? ''}}
                            </p>

                            <b class="mt-1 mb-1">Description</b>
                            <p class="mt-1 mb-1">
                                {{$post->description}}
                            </p>
                            <div class="mr-1 avatar avatar-xl">
                                <img src="{{url('/')}}/uploads/{{$post->user->profile_picture}}" alt="avtar img holder">
                            </div>
                            <a href="{{url('/')}}/users/detail?user_id={{$post->user->id}}">{{$post->user->name}}</a>
                        </div>
                    </div>
                </div>
                <div class="col-5">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Comments</h4>
                        </div>
                        <div class="card-body">
                            <div class="row" style="height: 400px; overflow:scroll;">
                                @foreach($comments as $key => $comment)
                                <div class="col-12 border-bottom">
                                    <div class="mr-1 avatar avatar-xl">
                                        <a href="{{url('/')}}/users/detail?user_id={{$comment->user->id}}"><img src="{{url('/')}}/uploads/{{$comment->user->profile_picture}}" alt="avtar img holder"></a>
                                    </div>
                                        {{$comment->comment}}
                                    <h2><a href="{{url('/')}}/users/detail?user_id={{$comment->user->id}}">{{$comment->user->name}}</a></h2>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
