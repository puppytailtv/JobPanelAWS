<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="mt-1 mb-2 content-header-left col-12">
                <div class="breadcrumbs-top">
                    <h5 class="float-left pr-1 mb-0 content-header-title">States</h5>
                    <div class="breadcrumb-wrapper d-none d-sm-block">
                        <ol class="p-0 pl-1 mb-0 breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                            </li>
                            <li class="breadcrumb-item active">States
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <div class="row" id="basic-table">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">States List</h4>
                        </div>
                        <div class="card-body">
                            <a href="<?php echo e(url('/')); ?>/states/edit"><button class="btn btn-secondary">Create</button></a>
                            <div class="table-responsive mt-2">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tables.states-table', [])->html();
} elseif ($_instance->childHasBeenRendered('nr4QgXR')) {
    $componentId = $_instance->getRenderedChildComponentId('nr4QgXR');
    $componentTag = $_instance->getRenderedChildComponentTagName('nr4QgXR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nr4QgXR');
} else {
    $response = \Livewire\Livewire::mount('tables.states-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('nr4QgXR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/happytail-laravel/resources/views/livewire/states/states-index-component.blade.php ENDPATH**/ ?>