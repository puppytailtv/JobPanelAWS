<?php if($loggedIn): ?>
<li class="dropdown dropdown-user nav-item"><a class="dropdown-toggle nav-link dropdown-user-link"
        href="javascript:void(0);" data-toggle="dropdown">
        <div class="user-nav d-sm-flex d-none"><span class="user-name"><?php echo e($user->name); ?></span></div><span>
            <img class="round" src="<?php echo e(url('/')); ?>/user.png" alt="avatar" height="40"
                width="40"></span>
    </a>
    <div class="pb-0 dropdown-menu dropdown-menu-right">
        <a class="dropdown-item" href="<?php echo e(url('/')); ?>"><i
                class="bx bx-power-off mr-50"></i> Logout</a>
    </div>
</li>
<?php endif; ?>
<?php /**PATH /var/www/html/happytail-laravel/resources/views/livewire/user-nav-menu.blade.php ENDPATH**/ ?>