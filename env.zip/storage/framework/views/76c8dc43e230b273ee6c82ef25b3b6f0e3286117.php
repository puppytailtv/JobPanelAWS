<div x-data class="flex flex-col">
    <select
        x-ref="select"
        name="<?php echo e($name); ?>"
        class="m-1 text-sm leading-4 flex-grow form-select"
        wire:input="doBooleanFilter('<?php echo e($index); ?>', $event.target.value)"
        x-on:input="$refs.select.value=''"
    >
        <option value=""></option>
        <option value="0"><?php echo e(__('No')); ?></option>
        <option value="1"><?php echo e(__('Yes')); ?></option>
    </select>

    <div class="flex flex-wrap max-w-48 space-x-1">
        <?php if(isset($this->activeBooleanFilters[$index])): ?>
        <?php if($this->activeBooleanFilters[$index] == 1): ?>
        <button wire:click="removeBooleanFilter('<?php echo e($index); ?>')"
            class="m-1 pl-1 flex items-center uppercase tracking-wide bg-gray-300 text-white hover:bg-red-600 rounded-full focus:outline-none text-xs space-x-1">
            <span><?php echo e(__('YES')); ?></span>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'icons::x-circle','data' => []]); ?>
<?php $component->withName('icons.x-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </button>
        <?php elseif(strlen($this->activeBooleanFilters[$index]) > 0): ?>
        <button wire:click="removeBooleanFilter('<?php echo e($index); ?>')"
            class="m-1 pl-1 flex items-center uppercase tracking-wide bg-gray-300 text-white hover:bg-red-600 rounded-full focus:outline-none text-xs space-x-1">
            <span><?php echo e(__('No')); ?></span>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'icons::x-circle','data' => []]); ?>
<?php $component->withName('icons.x-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </button>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div><?php /**PATH /var/www/html/happytail-laravel/resources/views/livewire/datatables/filters/boolean.blade.php ENDPATH**/ ?>