<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="mt-1 mb-2 content-header-left col-12">
                <div class="breadcrumbs-top">
                    <h5 class="float-left pr-1 mb-0 content-header-title">Users</h5>
                    <div class="breadcrumb-wrapper d-none d-sm-block">
                        <ol class="p-0 pl-1 mb-0 breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="bx bx-home-alt"></i></a>
                            </li>
                            <li class="breadcrumb-item active">Detail
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <div class="row" id="basic-table">
                <div class="col-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title"><?php echo e($user->name); ?></h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <img src="<?php echo e(url('/')); ?>/uploads/<?php echo e($user->profile_picture); ?>" />
                                </div>
                                <div class="col-md-8">
                                    <div class="row mt-2">
                                        <div class="col-md-12">
                                            <h2>Basic Information</h2>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-6">
                                            <label>Email: </label>
                                            <?php echo e($user->email); ?>

                                        </div>
                                        <div class="col-md-6">
                                            <label>Phone: </label>
                                            <?php echo e($user->phone); ?>

                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-6">
                                            <label>State: </label>
                                            <?php echo e($user->state->name ?? ''); ?>

                                        </div>
                                        <div class="col-md-6">
                                            <label>Address: </label>
                                            <?php echo e($user->address); ?>

                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-12">
                                            <h2>Stats</h2>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-6">
                                            <label>Videos: </label>
                                            <?php echo e($user->postsCount()); ?>

                                        </div>
                                        <div class="col-md-6">
                                            <label>Likes: </label>
                                            <?php echo e($user->likesCount()); ?>

                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-6">
                                            <label>Saved Videos: </label>
                                            <?php echo e($user->savedCount()); ?>

                                        </div>
                                        <div class="col-md-6">
                                            <label>Adoption Requests: </label>
                                            0
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Actions</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="custom-control custom-switch custom-control-inline mb-1">
                                        <input wire:change="update" wire:model="user.active" type="checkbox" class="custom-control-input" checked id="customSwitch1">
                                        <label class="custom-control-label mr-1" for="customSwitch1">
                                        </label>
                                        <span>Account Active</span>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="custom-control custom-switch custom-control-inline mb-1">
                                        <input wire:change="update" wire:model="user.active_publisher" type="checkbox" class="custom-control-input" checked id="customSwitch2">
                                        <label class="custom-control-label mr-1" for="customSwitch2">
                                        </label>
                                        <span>Publishing Active</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section id="nav-justified">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs nav-justified" id="myTab2" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab-justified" data-toggle="tab" href="#uploaded-videos" role="tab" aria-controls="uploaded-videos" aria-selected="true">
                                        Uploaded Videos
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab-justified" data-toggle="tab" href="#saved-videos" role="tab" aria-controls="saved-videos" aria-selected="true">
                                        Saved Videos
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="messages-tab-justified" data-toggle="tab" href="#liked-videos" role="tab" aria-controls="liked-videos" aria-selected="false">
                                        Liked Videos
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="settings-tab-justified" data-toggle="tab" href="#commented-videos" role="tab" aria-controls="commented-videos" aria-selected="false">
                                        Commented Videos
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="settings-tab-justified" data-toggle="tab" href="#adoption-in" role="tab" aria-controls="adoption-in" aria-selected="false">
                                        Adoption Requests Received
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="settings-tab-justified" data-toggle="tab" href="#adoption-out" role="tab" aria-controls="adoption-out" aria-selected="false">
                                        Adoption Requested
                                    </a>
                                </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content pt-1">
                                <div class="tab-pane active" id="uploaded-videos" role="tabpanel" aria-labelledby="home-tab-justified">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>
                                                    Name
                                                </th>
                                                <th>
                                                    Description
                                                </th>
                                                <th>
                                                    Breed
                                                </th>
                                                <th>
                                                    Color
                                                </th>
                                                <th>
                                                    State
                                                </th>
                                                <th>
                                                    Shipping Avl.
                                                </th>
                                                <th>
                                                    Price
                                                </th>
                                                <th>

                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($post->name); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($post->description); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($post->breed->name ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($post->color->name ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($post->state->name ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($post->shipping_available ? 'Yes' : 'No'); ?>

                                                </td>
                                                <td>
                                                    $<?php echo e($post->price); ?>

                                                </td>
                                                <td>
                                                    <a target="_blank" href="<?php echo e(url('/')); ?>/posts/view?post_id=<?php echo e($post->id); ?>">View</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane" id="saved-videos" role="tabpanel" aria-labelledby="profile-tab-justified">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>
                                                    Name
                                                </th>
                                                <th>
                                                    Description
                                                </th>
                                                <th>
                                                    Breed
                                                </th>
                                                <th>
                                                    Color
                                                </th>
                                                <th>
                                                    State
                                                </th>
                                                <th>
                                                    Shipping Avl.
                                                </th>
                                                <th>
                                                    Price
                                                </th>
                                                <th>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $user->savedVideos(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $savedPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($savedPost->name); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($savedPost->description); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($savedPost->breed->name ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($savedPost->color->name ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($savedPost->state->name ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($savedPost->shipping_available ? 'Yes' : 'No'); ?>

                                                </td>
                                                <td>
                                                    $<?php echo e($savedPost->price); ?>

                                                </td>
                                                <td>
                                                    <a target="_blank" href="<?php echo e(url('/')); ?>/posts/view?post_id=<?php echo e($savedPost->id); ?>">View</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                </div>
                                <div class="tab-pane" id="liked-videos" role="tabpanel" aria-labelledby="messages-tab-justified">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>
                                                    Name
                                                </th>
                                                <th>
                                                    Description
                                                </th>
                                                <th>
                                                    Breed
                                                </th>
                                                <th>
                                                    Color
                                                </th>
                                                <th>
                                                    State
                                                </th>
                                                <th>
                                                    Shipping Avl.
                                                </th>
                                                <th>
                                                    Price
                                                </th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $user->likedVideos(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $likedPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($likedPost->name); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($likedPost->description); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($likedPost->breed->name ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($likedPost->color->name ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($likedPost->state->name ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($likedPost->shipping_available ? 'Yes' : 'No'); ?>

                                                </td>
                                                <td>
                                                    $<?php echo e($likedPost->price); ?>

                                                </td>
                                                <td>
                                                    <a target="_blank" href="<?php echo e(url('/')); ?>/posts/view?post_id=<?php echo e($likedPost->id); ?>">View</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane" id="commented-videos" role="tabpanel" aria-labelledby="settings-tab-justified">
                                    <p>
                                        Biscuit powder jelly beans. Lollipop candy canes croissant icing chocolate cake. Cake fruitcake powder
                                        pudding pastry.I love caramels caramels halvah chocolate bar. Cotton candy
                                        gummi bears pudding pie apple pie cookie.
                                    </p>
                                </div>
                                <div class="tab-pane" id="adoption-in" role="tabpanel" aria-labelledby="settings-tab-justified">
                                    <table class="table">
                                        <tr>
                                            <th>Shelter</th>
                                            <th>Post</th>
                                            <th>State</th>
                                            <th>Breed</th>
                                            <th>Request Date</th>
                                        </tr>
                                        <?php $__currentLoopData = $adoptionIn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><a href="<?php echo e(url('/')); ?>/users/detail?user_id=<?php echo e($item->shelter->id); ?>"><?php echo e($item->shelter->name); ?></a></td>
                                            <td><a href="<?php echo e(url('/')); ?>/posts/view?post_id=}}$item->post->id||"><?php echo e($item->post->name); ?></a></td>
                                            <td><?php echo e($item->post->state->name); ?></td>
                                            <td><?php echo e($item->post->breed->name); ?></td>
                                            <td><?php echo e($item->created_at->format('d-m-Y h:i:s a')); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                                <div class="tab-pane" id="adoption-out" role="tabpanel" aria-labelledby="settings-tab-justified">
                                    <table class="table">
                                        <tr>
                                            <th>Shelter</th>
                                            <th>Post</th>
                                            <th>State</th>
                                            <th>Breed</th>
                                            <th>Request Date</th>
                                        </tr>
                                        <?php $__currentLoopData = $adoptionOut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><a href="<?php echo e(url('/')); ?>/users/detail?user_id=<?php echo e($item->shelter->id); ?>"><?php echo e($item->shelter->name); ?></a></td>
                                            <td><a href="<?php echo e(url('/')); ?>/posts/view?post_id=}}$item->post->id||"><?php echo e($item->post->name); ?></a></td>
                                            <td><?php echo e($item->post->state->name); ?></td>
                                            <td><?php echo e($item->post->breed->name); ?></td>
                                            <td><?php echo e($item->created_at->format('d-m-Y h:i:s a')); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php /**PATH /var/www/html/happytail-laravel/resources/views/livewire/users/user-details-component.blade.php ENDPATH**/ ?>