<div x-data class="flex flex-col">
    <div class="flex">
        <select
            x-ref="select"
            name="<?php echo e($name); ?>"
            class="text-sm leading-4 block rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
            wire:input="doSelectFilter('<?php echo e($index); ?>', $event.target.value)"
            x-on:input="$refs.select.value=''"
        >
            <option value=""></option>
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_object($label)): ?>
            <option value="<?php echo e($label->id); ?>"><?php echo e($label->name); ?></option>
            <?php elseif(is_array($label)): ?>
            <option value="<?php echo e($label['id']); ?>"><?php echo e($label['name']); ?></option>
            <?php elseif(is_numeric($value)): ?>
            <option value="<?php echo e($label); ?>"><?php echo e($label); ?></option>
            <?php else: ?>
            <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="flex flex-wrap max-w-48 space-x-1">
        <?php $__currentLoopData = $this->activeSelectFilters[$index] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button wire:click="removeSelectFilter('<?php echo e($index); ?>', '<?php echo e($key); ?>')" x-on:click="$refs.select.value=''"
            class="m-1 pl-1 flex items-center uppercase tracking-wide bg-gray-300 text-white hover:bg-red-600 rounded-full focus:outline-none text-xs space-x-1">
            <span><?php echo e($this->getDisplayValue($index, $value)); ?></span>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'icons::x-circle','data' => []]); ?>
<?php $component->withName('icons.x-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /var/www/html/happytail-laravel/resources/views/livewire/datatables/filters/select.blade.php ENDPATH**/ ?>