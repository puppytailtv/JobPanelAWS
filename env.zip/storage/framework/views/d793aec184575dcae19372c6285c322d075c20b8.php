<div>
    <?php if($beforeTableSlot): ?>
        <div class="mt-8">
            <?php echo $__env->make($beforeTableSlot, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endif; ?>
    <div class="relative">
        <div class="flex items-center justify-between mb-1">
            <div class="flex items-center flex-grow h-10">
                <?php if($this->searchableColumns()->count()): ?>
                <div class="flex rounded-lg shadow-sm w-96">
                    <div class="relative flex-grow focus-within:z-10">
                        <input wire:model.debounce.500ms="search" class="block w-full transition duration-150 ease-in-out rounded-md form-input form-control bg-gray-50 focus:bg-white sm:text-sm sm:leading-5" placeholder="<?php echo e(__('Search in')); ?> <?php echo e($this->searchableColumns()->map->label->join(', ')); ?>" />
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="flex justify-end text-gray-600">
                <?php echo e(__('Results')); ?> <?php echo e($this->results->firstItem()); ?> - <?php echo e($this->results->lastItem()); ?> <?php echo e(__('of')); ?>

                <?php echo e($this->results->total()); ?>

            </div>
            <div class="flex items-center space-x-1">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'icons::cog','data' => ['wire:loading' => true,'class' => 'text-gray-400 h-9 w-9 animate-spin']]); ?>
<?php $component->withName('icons.cog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:loading' => true,'class' => 'text-gray-400 h-9 w-9 animate-spin']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <?php if($exportable): ?>
                <div x-data="{ init() {
                    window.livewire.on('startDownload', link => window.open(link,'_blank'))
                } }" x-init="init">
                    <button wire:click="export" class="flex items-center px-3 space-x-2 text-xs font-medium leading-4 tracking-wider text-green-500 uppercase bg-white border border-green-400 rounded-md hover:bg-green-200 focus:outline-none"><span><?php echo e(__('Export')); ?></span>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'icons::excel','data' => ['class' => 'm-2']]); ?>
<?php $component->withName('icons.excel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'm-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></button>
                </div>
                <?php endif; ?>

                <?php if($hideable === 'select'): ?>
                <?php echo $__env->make('datatables::hide-column-multiselect', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
        </div>

        <?php if($hideable === 'buttons'): ?>
        <div class="grid grid-cols-8 gap-2 p-2">
            <?php $__currentLoopData = $this->columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button wire:click.prefetch="toggle('<?php echo e($index); ?>')" class="px-3 py-2 rounded text-white text-xs focus:outline-none
            <?php echo e($column['hidden'] ? 'bg-blue-100 hover:bg-blue-300 text-blue-600' : 'bg-blue-500 hover:bg-blue-800'); ?>">
                <?php echo e($column['label']); ?>

            </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <div class="overflow-x-scroll bg-white rounded-lg shadow-lg max-w-screen">
            <div class="rounded-lg <?php if (! ($this->hidePagination)): ?> rounded-b-none <?php endif; ?>">
                <div class="table min-w-full align-middle">
                    <?php if (! ($this->hideHeader)): ?>
                    <div class="table-row divide-x divide-gray-200">
                        <?php $__currentLoopData = $this->columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($hideable === 'inline'): ?>
                                <?php echo $__env->make('datatables::header-inline-hide', ['column' => $column, 'sort' => $sort], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($column['type'] === 'checkbox'): ?>
                            <div class="flex justify-center w-32 px-6 py-4 overflow-hidden text-xs font-medium leading-4 tracking-wider text-left text-gray-500 uppercase align-top border-b border-gray-200 bg-gray-50 focus:outline-none">
                                <div class="px-3 py-1 rounded <?php if(count($selected)): ?> bg-orange-400 <?php else: ?> bg-gray-200 <?php endif; ?> text-white text-center">
                                    <?php echo e(count($selected)); ?>

                                </div>
                            </div>
                            <?php else: ?>
                                <?php echo $__env->make('datatables::header-no-hide', ['column' => $column, 'sort' => $sort], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="table-row bg-blue-100 divide-x divide-blue-200">
                        <?php $__currentLoopData = $this->columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($column['hidden']): ?>
                                <?php if($hideable === 'inline'): ?>
                                    <div class="table-cell w-5 overflow-hidden align-top bg-blue-100"></div>
                                <?php endif; ?>
                            <?php elseif($column['type'] === 'checkbox'): ?>
                                <div class="flex flex-col items-center h-full px-6 py-5 space-y-2 overflow-hidden text-xs font-medium leading-4 tracking-wider text-left text-gray-500 uppercase align-top bg-blue-100 border-b border-gray-200 focus:outline-none">
                                    <div>SELECT ALL</div>
                                    <div>
                                        <input type="checkbox" wire:click="toggleSelectAll" <?php if(count($selected) === $this->results->total()): ?> checked <?php endif; ?> class="w-4 h-4 mt-1 text-blue-600 transition duration-150 ease-in-out form-checkbox" />
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="table-cell overflow-hidden align-top">
                                    <?php if(isset($column['filterable'])): ?>
                                        <?php if( is_iterable($column['filterable']) ): ?>
                                            <div wire:key="<?php echo e($index); ?>">
                                                <?php echo $__env->make('datatables::filters.select', ['index' => $index, 'name' => $column['label'], 'options' => $column['filterable']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        <?php else: ?>
                                            <div wire:key="<?php echo e($index); ?>">
                                                <?php echo $__env->make('datatables::filters.' . ($column['filterView'] ?? $column['type']), ['index' => $index, 'name' => $column['label']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $this->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="table-row p-1 divide-x divide-gray-100 <?php echo e(isset($result->checkbox_attribute) && in_array($result->checkbox_attribute, $selected) ? 'bg-orange-100' : ($loop->even ? 'bg-gray-100' : 'bg-gray-50')); ?>">
                            <?php $__currentLoopData = $this->columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($column['hidden']): ?>
                                    <?php if($hideable === 'inline'): ?>
                                    <div class="table-cell w-5 overflow-hidden align-top"></div>
                                    <?php endif; ?>
                                <?php elseif($column['type'] === 'checkbox'): ?>
                                    <?php echo $__env->make('datatables::checkbox', ['value' => $result->checkbox_attribute], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php else: ?>
                                    <div class="px-6 py-2 whitespace-no-wrap text-sm leading-5 text-gray-900 table-cell <?php if($column['align'] === 'right'): ?> text-right <?php elseif($column['align'] === 'center'): ?> text-center <?php else: ?> text-left <?php endif; ?>">
                                        <?php echo $result->{$column['name']}; ?>

                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="p-3 text-lg text-teal-600">
                            <?php echo e(__("There's Nothing to show at the moment")); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <?php if (! ($this->hidePagination)): ?>
            <div class="bg-white border-b border-gray-200 rounded-lg rounded-t-none max-w-screen">
                <div class="items-center justify-between p-2 sm:flex">
                    
                    <?php if(count($this->results)): ?>
                        <div class="flex items-center my-2 sm:my-0">
                            <select name="perPage" class="block w-full py-2 pl-3 pr-10 mt-1 text-base leading-6 border-gray-300 form-select focus:outline-none focus:shadow-outline-blue focus:border-blue-300 sm:text-sm sm:leading-5" wire:model="perPage">
                                <?php $__currentLoopData = config('livewire-datatables.per_page_options', [ 10, 25, 50, 100 ]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per_page_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($per_page_option); ?>"><?php echo e($per_page_option); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <option value="99999999"><?php echo e(__('All')); ?></option>
                            </select>
                        </div>

                        <div class="my-4 sm:my-0">
                            <div class="lg:hidden">
                                <span class="space-x-2"><?php echo e($this->results->links('datatables::tailwind-simple-pagination')); ?></span>
                            </div>

                            <div class="justify-center hidden lg:flex">
                                <span><?php echo e($this->results->links('datatables::tailwind-pagination')); ?></span>
                            </div>
                        </div>

                        <div class="flex justify-end text-gray-600">
                            <?php echo e(__('Results')); ?> <?php echo e($this->results->firstItem()); ?> - <?php echo e($this->results->lastItem()); ?> <?php echo e(__('of')); ?>

                            <?php echo e($this->results->total()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php if($afterTableSlot): ?>
    <div class="mt-8">
        <?php echo $__env->make($afterTableSlot, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/happytail-laravel/resources/views/livewire/datatables/datatable.blade.php ENDPATH**/ ?>